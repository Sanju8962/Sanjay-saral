import React from 'react';

const quizData = [
  {
    question: "बाल विकास का मुख्य उद्देश्य क्या है?",
    options: ["परीक्षा", "समझ", "शिक्षा", "व्यवहार"],
    answer: "समझ"
  },
  {
    question: "शिक्षा शास्त्र किससे संबंधित है?",
    options: ["गणित", "विज्ञान", "मानव व्यवहार", "खेल"],
    answer: "मानव व्यवहार"
  }
];

export default function App() {
  const [current, setCurrent] = React.useState(0);
  const [selected, setSelected] = React.useState("");
  const [showResult, setShowResult] = React.useState(false);

  const currentQuiz = quizData[current];

  const handleSubmit = () => {
    if (current + 1 < quizData.length) {
      setCurrent(current + 1);
      setSelected("");
    } else {
      setShowResult(true);
    }
  };

  return (
    <div style={{ padding: 20 }}>
      <h2>🧠 संजू क्विज़</h2>
      {showResult ? (
        <div>🎉 क्विज़ पूरा हुआ!</div>
      ) : (
        <>
          <p><strong>प्रश्न:</strong> {currentQuiz.question}</p>
          {currentQuiz.options.map((opt) => (
            <div key={opt}>
              <label>
                <input
                  type="radio"
                  name="option"
                  value={opt}
                  checked={selected === opt}
                  onChange={() => setSelected(opt)}
                />
                {" "}{opt}
              </label>
            </div>
          ))}
          <button onClick={handleSubmit} disabled={!selected} style={{ marginTop: 10 }}>
            आगे बढ़ें
          </button>
        </>
      )}
    </div>
  );
}
